#!/bin/bash

OUTPUT=$(yad --width=400 --title="Zoom" --text="Introduce codul sau linkul Zoom" \
--form \
--field="Link" \
--field="SAU cod")

link=$(echo $OUTPUT | awk 'BEGIN {FS="|" } { print $1 }')
code=$(echo $OUTPUT | awk 'BEGIN {FS="|" } { print $2 }')

if [ -z "$link" ]; then
	code=$(echo ${code//[[:blank:]]/})
	open_link=$(python3 zoom.py $code "code")
fi

if [ -n "$link" ]; then
	open_link=$(python3 zoom.py $link "link")
fi


chromium-browser $open_link
