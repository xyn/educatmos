#!/usr/bin/python3
import sys

def generate_link(orig_url, type):
	if(type=="link"):
		meeting_code=orig_url.split(".zoom.us/j/")[1].split("?pwd=")[0]
		pwd=orig_url.split(".zoom.us/j/")[1].split("?pwd=")[1]
		host=orig_url.split(".zoom.us/j/")[0]
		return host+".zoom.us/wc/join/"+meeting_code+"?pwd="+pwd
	elif(type=="code"):
		return "https://us05web.zoom.us/wc/join/"+str(orig_url)

print(generate_link(sys.argv[1], sys.argv[2]))
